# The-Modern-JavaScript-Bootcamp-2019
The Modern JavaScript Bootcamp (2019), published by Packt
